public class Square extends GeometricFigureApp{
    private double sideLength;

    public Square(double sideLength) {
        this.sideLength = sideLength;
    }

    public double getSideLength() {
        return sideLength;
    }

    public double calculateArea() {
        // Implementation
        return 0.0;
    }

    public double calculatePerimeter() {
        // Implementation
        return 0.0;
    }
}
