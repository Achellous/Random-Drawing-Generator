public class Circle extends GeometricFigureApp {
    // Attribute for Circle
    private double radius;

    // Constructor
    public Circle(double radius) {
        this.radius = radius;
    }

    // Method to get radius
    public double getRadius() {
        return radius;
    }

    // Methods to calculate area and circumference
    public double calculateArea() {
        // Implementation goes here
        return 0.0;
    }

    public double calculateCircumference() {
        // Implementation
        return 0.0;
    }
}
