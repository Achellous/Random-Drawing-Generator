import java.awt.Color;

public class GeometricFigureApp {
    private Point startPoint;
    private Point b;
    private Color fill;
    private Color outline;
    private boolean transparent;

    public void fillFigure(Color fill, Color outline, boolean transparent) {

    }
}
